import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;

class ListaInvertida {

    // Inversão por classificação
    public void WriteInFirstInvertedList(){ 
        RandomAccessFile arq;
        RandomAccessFile firstFile;

        try {
            arq = new RandomAccessFile("conteudos.bin", "rw"); // Arquivo que vai ser lido 
            
            try {
                firstFile = new RandomAccessFile("InvertedListByRating.bin", "rw"); // Arquivo da primeira lista invertida
                // Posicionando o ponteiro do arquivo no comeco, desconsiderando o maior ID
                arq.seek(4);

                boolean aux = false;

                ArrayList<Long> Tm = new ArrayList<Long>();
                ArrayList<Long> T14 = new ArrayList<Long>();
                ArrayList<Long> P13 = new ArrayList<Long>();
                ArrayList<Long> Tp = new ArrayList<Long>();
                ArrayList<Long> Ty = new ArrayList<Long>();
                ArrayList<Long> N17 = new ArrayList<Long>();

                while(arq.getFilePointer() < arq.length()){
                    int size = arq.readInt();
                    byte[] ba = new byte[size];
                    arq.read(ba);

                    Conteudo c = new Conteudo();
                    c.fromByteArray(ba);

                    if(c.getLapide() == 0){
                        if(c.getRating().equals("TV-MA")){
                            Tm.add(arq.getFilePointer() - size - 4);
                        }else if(c.getRating().equals("TV-14")){
                            T14.add(arq.getFilePointer() - size - 4);
                        }else if(c.getRating().equals("PG-13")){
                            P13.add(arq.getFilePointer() - size - 4);
                        }else if(c.getRating().equals("TV-PG")){
                            Tp.add(arq.getFilePointer() - size - 4);
                        }else if(c.getRating().equals("TV-Y7")){
                            Ty.add(arq.getFilePointer() - size - 4);
                        }else if(c.getRating().equals("NC-17")){
                            N17.add(arq.getFilePointer() - size - 4);
                        }
                    }
                }

                for(int i = 0; i < Tm.size(); i++){
                    if(!aux){
                        firstFile.writeUTF("TV-MA");
                        aux = true;
                    }
                    firstFile.writeBoolean(false);
                    firstFile.writeLong(Tm.get(i));
                }
                firstFile.writeBoolean(true);
                aux = false;
                for(int i = 0; i < T14.size(); i++){
                    if(!aux){
                        firstFile.writeUTF("TV-14");
                        aux = true;
                    }
                    firstFile.writeBoolean(false);
                    firstFile.writeLong(T14.get(i));
                }
                firstFile.writeBoolean(true);
                aux = false;
                for(int i = 0; i < P13.size(); i++){
                    if(!aux){
                        firstFile.writeUTF("PG-13");
                        aux = true;
                    }
                    firstFile.writeBoolean(false);
                    firstFile.writeLong(P13.get(i));
                }
                firstFile.writeBoolean(true);
                aux = false;
                for(int i = 0; i < Tp.size(); i++){
                    if(!aux){
                        firstFile.writeUTF("TV-PG");
                        aux = true;
                    }
                    firstFile.writeBoolean(false);
                    firstFile.writeLong(Tp.get(i));
                }
                firstFile.writeBoolean(true);
                aux = false;
                for(int i = 0; i < Ty.size(); i++){
                    if(!aux){
                        firstFile.writeUTF("TV-Y7");
                        aux = true;
                    }
                    firstFile.writeBoolean(false);
                    firstFile.writeLong(Ty.get(i));
                }
                firstFile.writeBoolean(true);
                aux = false;
                for(int i = 0; i < N17.size(); i++){
                    if(!aux){
                        firstFile.writeUTF("NC-17");
                        aux = true;
                    }
                    firstFile.writeBoolean(false);
                    firstFile.writeLong(N17.get(i));
                }

                arq.close();
                firstFile.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } 
    }

    // Inversão por ano de lançamento
    public void WriteInSecondInvertedList(){
        RandomAccessFile arq;
        RandomAccessFile secondFile;

        try {
            arq = new RandomAccessFile("conteudos.bin", "r"); // Arquivo que vai ser lido

            try {
                secondFile = new RandomAccessFile("InvertedListByReleaseYear.bin", "rw"); // Arquivo da segunda lista invertida

                // Posicionando o ponteiro do arquivo no comeco, desconsiderando o maior ID
                arq.seek(4);

                boolean aux = false;

                ArrayList<Long> A21 = new ArrayList<Long>();
                ArrayList<Long> A20 = new ArrayList<Long>();
                ArrayList<Long> A19 = new ArrayList<Long>();
                ArrayList<Long> A18 = new ArrayList<Long>();
                ArrayList<Long> A17 = new ArrayList<Long>();
                ArrayList<Long> A16 = new ArrayList<Long>();

                while(arq.getFilePointer() < arq.length()){
                    int size = arq.readInt();
                    byte[] ba = new byte[size];
                    arq.read(ba);

                    Conteudo c = new Conteudo();
                    c.fromByteArray(ba);

                    if(c.getLapide() == 0){
                        if(c.getReleaseYear() == 2021){
                            A21.add(arq.getFilePointer() - size -4);
                        }else if(c.getReleaseYear() == 2020){
                            A20.add(arq.getFilePointer() - size -4);
                        }else if(c.getReleaseYear() == 2019){
                            A19.add(arq.getFilePointer() - size -4);
                        }else if(c.getReleaseYear() == 2018){
                            A18.add(arq.getFilePointer() - size -4);
                        }else if(c.getReleaseYear() == 2017){
                            A17.add(arq.getFilePointer() - size -4);
                        }else if(c.getReleaseYear() == 2016){
                            A16.add(arq.getFilePointer() - size -4);
                        }
                    }
                }

                for(int i = 0; i < A21.size(); i++){
                    if(!aux){
                        secondFile.writeInt(2021);
                        aux = true;
                    }
                    secondFile.writeBoolean(false);
                    secondFile.writeLong(A21.get(i));
                }
                secondFile.writeBoolean(true);
                aux = false;
                for(int i = 0; i < A20.size(); i++){
                    if(!aux){
                        secondFile.writeInt(2020);
                        aux = true;
                    }
                    secondFile.writeBoolean(false);
                    secondFile.writeLong(A20.get(i));
                }
                secondFile.writeBoolean(true);
                aux = false;
                for(int i = 0; i < A19.size(); i++){
                    if(!aux){
                        secondFile.writeInt(2019);
                        aux = true;
                    }
                    secondFile.writeBoolean(false);
                    secondFile.writeLong(A19.get(i));
                }
                secondFile.writeBoolean(true);
                aux = false;
                for(int i = 0; i < A18.size(); i++){
                    if(!aux){
                        secondFile.writeInt(2018);
                        aux = true;
                    }
                    secondFile.writeBoolean(false);
                    secondFile.writeLong(A18.get(i));
                }
                secondFile.writeBoolean(true);
                aux = false;
                for(int i = 0; i < A17.size(); i++){
                    if(!aux){
                        secondFile.writeInt(2017);
                        aux = true;
                    }
                    secondFile.writeBoolean(false);
                    secondFile.writeLong(A17.get(i));
                }
                secondFile.writeBoolean(true);
                aux = false;
                for(int i = 0; i < A16.size(); i++){
                    if(!aux){
                        secondFile.writeInt(2016);
                        aux = true;
                    }
                    secondFile.writeBoolean(false);
                    secondFile.writeLong(A16.get(i));
                }

                arq.close();
                secondFile.close();
            } catch (IOException e) {
                e.printStackTrace();
            } 
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } 
    }

    public static Conteudo read(long pos){
        RandomAccessFile arq;
        Conteudo c = new Conteudo();
        try {
            arq = new RandomAccessFile("conteudos.bin", "rw");
            arq.seek(pos);

            int tam = arq.readInt();
            byte[] ba = new byte[tam];
            arq.read(ba);
            c.fromByteArray(ba);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return c;
    }

    public void searchInFirstInvertedList(String search){
        RandomAccessFile firstFile;

        try {
            firstFile = new RandomAccessFile("InvertedListByRating.bin", "rw");

            firstFile.seek(0); // Movendo o ponteiro para o incio do arquivo
            String str = firstFile.readUTF(); // Variavel para auxiliar na leitura do arquivo
            long i = 0;

            while(firstFile.getFilePointer() != firstFile.length()){ 
                if(firstFile.readBoolean() == false){
                    i = firstFile.readLong();
                    
                    if(str.equals(search)){
                        Conteudo c = read(i);
                        System.out.println(c);
                    }
                    
                }else{
                    str = firstFile.readUTF();
                }
            }

            firstFile.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void searchInSecondInvertedList(int search){
        RandomAccessFile secondFile;

        try {
            secondFile = new RandomAccessFile("InvertedListByReleaseYear.bin", "rw");

            secondFile.seek(0); // Movendo o ponteiro para o incio do arquivo
            int v = secondFile.readInt(); // Variavel para auxiliar na leitura do arquivo
            long i = 0;

            while(secondFile.getFilePointer() != secondFile.length()){ 
                if(secondFile.readBoolean() == false){
                    i = secondFile.readLong();
                    
                    if(v == search){
                        Conteudo c = read(i);
                        System.out.println(c);
                    }
                    
                }else{
                    v = secondFile.readInt();
                }
            }

            secondFile.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private ArrayList<Long> auxList1(String search){
        RandomAccessFile firstFile;
        ArrayList<Long> arr = new ArrayList<Long>();

        try {
            firstFile = new RandomAccessFile("InvertedListByRating.bin", "rw");

            firstFile.seek(0); // Movendo o ponteiro para o incio do arquivo
            String str = firstFile.readUTF(); // Variavel para auxiliar na leitura do arquivo
            long i = 0;

            while(firstFile.getFilePointer() != firstFile.length()){ 
                if(firstFile.readBoolean() == false){
                    i = firstFile.readLong();
                    
                    if(str.equals(search)){
                        arr.add(i);
                    }
                    
                }else{
                    str = firstFile.readUTF();
                }
            }

            firstFile.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return arr;
    }

    private ArrayList<Long> auxList2(int search){
        RandomAccessFile secondFile;
        ArrayList<Long> arr = new ArrayList<Long>();
        try {
            secondFile = new RandomAccessFile("InvertedListByReleaseYear.bin", "rw");

            secondFile.seek(0); // Movendo o ponteiro para o incio do arquivo
            int v = secondFile.readInt(); // Variavel para auxiliar na leitura do arquivo
            long i = 0;
            while(secondFile.getFilePointer() != secondFile.length()){ 
                if(secondFile.readBoolean() == false){
                    i = secondFile.readLong();
                    
                    if(v == search){
                        arr.add(i);
                    }
                    
                }else{
                    v = secondFile.readInt();
                }
            }

            secondFile.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return arr;
    }

    // Método para ler as duas listas invertidas
    public boolean searchInTwoInvertedLists(int v, String str) {
        boolean resp = false;

        ArrayList<Long> f1 = auxList1(str);
        ArrayList<Long> f2 = auxList2(v);
        
        int tam1 = Math.min(f1.size(), f2.size());
        int tam2 = Math.max(f1.size(), f2.size());
        long f1Value = 0, f2Value = 0;
        Conteudo c1, c2;
        
        for (int i = 0; i < tam1; i++) {
            f1Value = f1.get(i);
            c1 = read(f1Value);
            
            for(int j = 0; j < tam2; j++){
                f2Value = f2.get(j);
                c2 = read(f2Value);
                
                if(c1.getId() == c2.getId()){
                    System.out.println(c1);
                    resp = true;
                }
                    
            }
        }
        return resp;
    }

    public void interface1(){
        System.out.println("\n1 - Pesquisar em uma lista invertida.");
        System.out.println("2 - Pesquisar nas duas listas invertidas.");
        System.out.println("0 - Para sair.\n");
    }

    public void interface2(){
        System.out.println("\n1 - Pesquisar na lista invertida de classificacao.");
        System.out.println("2 - Pesquisar na lista invertida de ano de lancamento.");
        System.out.println("0 - Para sair.\n");
    }

    public void interface3(){
        System.out.println("\nPesquisar por qual classificacao?");
        System.out.println("1 - TV-MA.");
        System.out.println("2 - TV-14.");
        System.out.println("3 - PG-13.");
        System.out.println("4 - TV-PG.");
        System.out.println("5 - TV-Y7.");
        System.out.println("6 - NC-17.");
    }

    public void interface4(){
        System.out.println("\nPesquisar por qual ano de lancamento?");
        System.out.println("    2021.");
        System.out.println("    2020.");
        System.out.println("    2019.");
        System.out.println("    2018.");
        System.out.println("    2017.");
        System.out.println("    2016.");
    }
}
