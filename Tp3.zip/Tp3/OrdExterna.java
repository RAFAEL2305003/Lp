import java.io.File;
import java.io.RandomAccessFile;
import java.util.Scanner;

public class OrdExterna {

    static Scanner scan;

    public OrdExterna(Scanner s) {
        scan = s;
    }

    static int readIdBeginning(RandomAccessFile arq) { // Le o ultimo id adicionado, que esta no comeco do arquivo e o
        // retorna

        int id = 0;

        try {

            arq.seek(0);
            id = arq.readInt();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return id;

    }

    static void writeIdBeginning(RandomAccessFile arq, int id) { // Escreve o id no inicio do arquivo

        try {
            arq.seek(0);
            arq.writeInt(id);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static void swap(Conteudo[] array, int i, int j) {
        Conteudo aux = new Conteudo();

        aux = array[i];
        array[i] = array[j];
        array[j] = aux;
    }

    private static void quicksort(Conteudo[] array, int esq, int dir) {

        int i = esq, j = dir;
        Conteudo pivo = array[(esq + dir) / 2];
        while (i <= j) {
            while (array[i].getId() < pivo.getId()) {
                i++;
            }
            while (array[j].getId() > pivo.getId()) {
                j--;
            }
            if (i <= j) {
                swap(array, i, j);
                i++;
                j--;
            }
        }
        if (esq < j) {
            quicksort(array, esq, j);
        }

        if (i < dir) {
            quicksort(array, i, dir);
        }
    }

    private static void interComum(int quant, boolean wich, RandomAccessFile arqTemp1, RandomAccessFile arqTemp2,
            RandomAccessFile arqTemp3, RandomAccessFile arqTemp4) { // Intercala lendo do Temp 3 e 4 e escreve nos Temp
                                                                    // 1 e 2
        try {
            RandomAccessFile arqRead1;
            RandomAccessFile arqRead2;
            RandomAccessFile arqWrite1;
            RandomAccessFile arqWrite2;
            if (wich) {
                arqRead1 = arqTemp1;
                arqRead2 = arqTemp2;
                arqWrite1 = arqTemp3;
                arqWrite2 = arqTemp4;
            } else {
                arqRead1 = arqTemp3;
                arqRead2 = arqTemp4;
                arqWrite1 = arqTemp1;
                arqWrite2 = arqTemp2;
            }

            arqRead1.seek(0);
            arqRead2.seek(0);
            arqWrite1.setLength(0);
            arqWrite2.setLength(0);

            Conteudo c1 = new Conteudo();
            Conteudo c2 = new Conteudo();
            byte[] ba;
            int tam, q1, q2;
            boolean aux = true;
            boolean a1, a2;

            RandomAccessFile arq = arqWrite1;

            while (arqRead1.getFilePointer() != arqRead1.length() || arqRead2.getFilePointer() != arqRead2.length()) {

                a1 = a2 = false;
                q1 = q2 = 0;

                if (arqRead1.getFilePointer() == arqRead1.length()) {
                    a1 = true;
                    tam = arqRead2.readInt();
                    ba = new byte[tam];
                    arqRead2.read(ba);
                    c2.fromByteArray(ba);
                } else if (arqRead2.getFilePointer() == arqRead2.length()) {
                    a2 = true;
                    tam = arqRead1.readInt();
                    ba = new byte[tam];
                    arqRead1.read(ba);
                    c1.fromByteArray(ba);
                } else {
                    tam = arqRead1.readInt();
                    ba = new byte[tam];
                    arqRead1.read(ba);
                    c1.fromByteArray(ba);

                    tam = arqRead2.readInt();
                    ba = new byte[tam];
                    arqRead2.read(ba);
                    c2.fromByteArray(ba);
                }

                if (aux) {
                    arq = arqWrite1;
                } else {
                    arq = arqWrite2;
                }

                aux = !aux;

                while (!a1 || !a2) {

                    if (a1) {

                        ba = c2.toByteArray();
                        arq.writeInt(ba.length);
                        arq.write(ba);
                        q2++;
                        while (arqRead2.getFilePointer() != arqRead2.length() && q2 < quant) {

                            tam = arqRead2.readInt();
                            ba = new byte[tam];
                            arqRead2.read(ba);
                            c2.fromByteArray(ba);

                            ba = c2.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q2++;

                        }
                        a2 = true;
                    } else if (a2) {

                        ba = c1.toByteArray();
                        arq.writeInt(ba.length);
                        arq.write(ba);
                        q1++;

                        while (arqRead1.getFilePointer() != arqRead1.length() && q1 < quant) {

                            tam = arqRead1.readInt();
                            ba = new byte[tam];
                            arqRead1.read(ba);
                            c1.fromByteArray(ba);

                            ba = c1.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q1++;

                        }
                        a1 = true;
                    } else {

                        if (c1.getId() > c2.getId()) {
                            ba = c2.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q2++;

                            if (arqRead2.getFilePointer() != arqRead2.length() && q2 < quant) {
                                tam = arqRead2.readInt();
                                ba = new byte[tam];
                                arqRead2.read(ba);
                                c2.fromByteArray(ba);
                            } else {
                                a2 = true;
                            }
                        } else {
                            ba = c1.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q1++;

                            if (arqRead1.getFilePointer() != arqRead1.length() && q1 < quant) {
                                tam = arqRead1.readInt();
                                ba = new byte[tam];
                                arqRead1.read(ba);
                                c1.fromByteArray(ba);
                            } else {
                                a1 = true;
                            }
                        }
                    }
                }

            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static int interVariavel(boolean wich, RandomAccessFile arqTemp1, RandomAccessFile arqTemp2,
            RandomAccessFile arqTemp3, RandomAccessFile arqTemp4) { // Intercala os dados com blocos de tamanho variavel

        Conteudo c1 = new Conteudo();
        Conteudo c2 = new Conteudo();
        byte[] ba;
        int tam, q1, q2, quant = 0;
        boolean aux = true;
        boolean a1, a2;

        try {
            RandomAccessFile arqRead1;
            RandomAccessFile arqRead2;
            RandomAccessFile arqWrite1;
            RandomAccessFile arqWrite2;
            if (wich) {
                arqRead1 = arqTemp1;
                arqRead2 = arqTemp2;
                arqWrite1 = arqTemp3;
                arqWrite2 = arqTemp4;
            } else {
                arqRead1 = arqTemp3;
                arqRead2 = arqTemp4;
                arqWrite1 = arqTemp1;
                arqWrite2 = arqTemp2;
            }

            arqRead1.seek(0);
            arqRead2.seek(0);
            arqWrite1.setLength(0);
            arqWrite2.setLength(0);

            RandomAccessFile arq = arqWrite1;

            while (arqRead1.getFilePointer() != arqRead1.length() || arqRead2.getFilePointer() != arqRead2.length()) {

                a1 = a2 = false;
                q1 = q2 = 0;

                if (arqRead1.getFilePointer() == arqRead1.length()) {
                    a1 = true;
                    tam = arqRead2.readInt();
                    ba = new byte[tam];
                    arqRead2.read(ba);
                    c2.fromByteArray(ba);
                } else if (arqRead2.getFilePointer() == arqRead2.length()) {
                    a2 = true;
                    tam = arqRead1.readInt();
                    ba = new byte[tam];
                    arqRead1.read(ba);
                    c1.fromByteArray(ba);
                } else {
                    tam = arqRead1.readInt();
                    ba = new byte[tam];
                    arqRead1.read(ba);
                    c1.fromByteArray(ba);

                    tam = arqRead2.readInt();
                    ba = new byte[tam];
                    arqRead2.read(ba);
                    c2.fromByteArray(ba);
                }

                if (aux) {
                    arq = arqWrite1;
                } else {
                    arq = arqWrite2;
                }

                aux = !aux;

                while (!a1 || !a2) {

                    if (a1) {

                        while (arqRead2.getFilePointer() != arqRead2.length() && c2.getId() > q2) {

                            ba = c2.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q2 = c2.getId();
                            quant++;

                            tam = arqRead2.readInt();
                            ba = new byte[tam];
                            arqRead2.read(ba);
                            c2.fromByteArray(ba);

                        }
                        if (arqRead2.getFilePointer() == arqRead2.length()) {
                            ba = c2.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q2 = c2.getId();
                            quant++;
                        }
                        if (arqRead1.getFilePointer() == arqRead1.length()) {
                            ba = c2.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q2 = c2.getId();
                            quant++;
                        }

                        a2 = true;

                    } else if (a2) {

                        while (arqRead1.getFilePointer() != arqRead1.length() && c1.getId() > q1) {

                            ba = c1.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q1 = c1.getId();
                            quant++;

                            tam = arqRead1.readInt();
                            ba = new byte[tam];
                            arqRead1.read(ba);
                            c1.fromByteArray(ba);

                        }

                        if (arqRead1.getFilePointer() == arqRead1.length()) {
                            ba = c1.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q1 = c1.getId();
                            quant++;
                        }

                        if (arqRead2.getFilePointer() == arqRead2.length()) {
                            ba = c1.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q1 = c1.getId();
                            quant++;
                        }

                        a1 = true;
                    } else {

                        if (c1.getId() > c2.getId()) {
                            ba = c2.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q2 = c2.getId();
                            quant++;

                            if (arqRead2.getFilePointer() != arqRead2.length()) {
                                tam = arqRead2.readInt();
                                ba = new byte[tam];
                                arqRead2.read(ba);
                                c2.fromByteArray(ba);
                                if (c2.getId() < q2) {
                                    arqRead2.seek(arqRead2.getFilePointer() - tam - 4);
                                    a2 = true;
                                }
                            } else {
                                a2 = true;
                            }
                        } else {
                            ba = c1.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q1 = c1.getId();
                            quant++;

                            if (arqRead1.getFilePointer() != arqRead1.length()) {
                                tam = arqRead1.readInt();
                                ba = new byte[tam];
                                arqRead1.read(ba);
                                c1.fromByteArray(ba);
                                if (c1.getId() < q1) {
                                    arqRead1.seek(arqRead1.getFilePointer() - tam - 4);
                                    a1 = true;
                                }
                            } else {
                                a1 = true;
                            }
                        }
                    }
                }
                if (aux) {
                    quant = 0;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return quant;
    }

    public void interBalanceada(int mode) {

        byte[] ba;
        int tam, quant = 100;

        Conteudo c = new Conteudo();

        Conteudo[] conts = new Conteudo[quant];

        try {

            RandomAccessFile arq = new RandomAccessFile("conteudos.bin", "rw");
            RandomAccessFile arqTemp1 = new RandomAccessFile("arqTemp1.bin", "rw");
            RandomAccessFile arqTemp2 = new RandomAccessFile("arqTemp2.bin", "rw");
            RandomAccessFile arqTemp3 = new RandomAccessFile("arqTemp3.bin", "rw");
            RandomAccessFile arqTemp4 = new RandomAccessFile("arqTemp4.bin", "rw");

            arqTemp1.setLength(0);
            arqTemp2.setLength(0);
            arqTemp3.setLength(0);
            arqTemp4.setLength(0);

            int qReg = readIdBeginning(arq);

            arq.seek(4);

            boolean aux = true;

            while (arq.getFilePointer() != arq.length()) {

                for (int i = 0; i < quant; i++) {
                    conts[i] = null;
                }
                int k = 0;
                while (k < quant && arq.getFilePointer() != arq.length()) {

                    c = new Conteudo();

                    tam = arq.readInt();
                    ba = new byte[tam];
                    arq.read(ba);

                    c.fromByteArray(ba);
                    if (c.lapide == 0) {
                        conts[k] = c;
                        k++;
                    }
                }

                Conteudo[] array;

                int q = 0;

                if (conts[quant - 1] == null) {

                    for (int i = 0; i < quant; i++) {
                        if (conts[i] != null) {
                            q++;
                        }
                    }

                    array = new Conteudo[q];

                    for (int i = 0; i < q; i++) {
                        array[i] = conts[i];
                    }

                } else {

                    array = conts;
                    q = array.length;

                }

                quicksort(array, 0, q - 1);

                if (aux) {
                    for (int i = 0; i < q; i++) {
                        c = array[i];
                        ba = c.toByteArray();
                        arqTemp1.writeInt(ba.length);
                        arqTemp1.write(ba);
                    }
                } else {
                    for (int i = 0; i < q; i++) {
                        c = array[i];
                        ba = c.toByteArray();
                        arqTemp2.writeInt(ba.length);
                        arqTemp2.write(ba);
                    }
                }

                aux = !aux;
            }
            aux = true;
            int cont = 0;
            switch (mode) {
                case 1:
                    while (quant < qReg) {

                        interComum(quant, aux, arqTemp1, arqTemp2, arqTemp3, arqTemp4);

                        quant *= 2;
                        aux = !aux;
                        cont++;
                    }
                    break;

                case 2:
                    while (quant < qReg) {

                        quant = interVariavel(aux, arqTemp1, arqTemp2, arqTemp3, arqTemp4);
                        aux = !aux;
                        cont++;
                    }
                    break;

                default:
                    break;
            }

            RandomAccessFile arqAux = arqTemp1;

            if (cont % 2 == 0) {
                arqAux = arqTemp1;
            } else {
                arqAux = arqTemp3;
            }

            arqAux.seek(0);
            arq.setLength(0);
            writeIdBeginning(arq, 0);
            while (arqAux.getFilePointer() != arqAux.length()) {
                arq.seek(arq.length());
                tam = arqAux.readInt();
                ba = new byte[tam];
                arqAux.read(ba);

                c.fromByteArray(ba);

                arq.writeInt(tam);
                arq.write(ba);

                writeIdBeginning(arq, c.getId());
            }

            arq.close();
            arqTemp1.close();
            arqTemp2.close();
            arqTemp3.close();
            arqTemp4.close();
            File f = new File("arqTemp1.bin");
            f.delete();
            f = new File("arqTemp2.bin");
            f.delete();
            f = new File("arqTemp3.bin");
            f.delete();
            f = new File("arqTemp4.bin");
            f.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    static long find(int id, Conteudo c) {

        byte[] ba;
        int tam;
        long pos = 0;
        boolean found = false;

        try {

            RandomAccessFile arq = new RandomAccessFile("conteudos.bin", "rw");

            arq.seek(4);

            while (arq.getFilePointer() != arq.length() && !found) {

                tam = arq.readInt();
                ba = new byte[tam];
                pos = arq.getFilePointer();
                arq.read(ba);

                c.fromByteArray(ba);

                if (c.getLapide() == 0 && c.id == id) {
                    found = true;
                }
            }

            if (!found) {
                pos = 0;
            }

            arq.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return pos;
    }

    private static void changeTitle(Conteudo c) { // Altera o titulo do conteudo

        System.out.println("Antigo title(titulo) =  " + c.title);
        System.out.print("Digite o novo: ");
        c.title = scan.nextLine();

    }

    private static void changeCast(Conteudo c) { // Altera o elenco do conteudo

        System.out.println("Antigo cast(elenco) =  " + c.cast);
        System.out.print("Digite o novo: ");
        c.cast = scan.nextLine();

    }

    private static void changeDate(Conteudo c) { // Altera a data do conteudo
        try {
            System.out.println("Data antiga =  " + c.dateFormat.format(c.date_added));
            System.out.print("Digite a nova: ");
            c.date_added = c.dateFormat.parse(scan.nextLine());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static void changeYear(Conteudo c) { // Altera o ano do conteudo
        try {
            System.out.println("Antigo ano =  " + c.release_year);
            System.out.print("Digite o novo: ");
            c.release_year = Integer.parseInt(scan.nextLine());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static void changeRating(Conteudo c) { // Altera a classificacao do conteudo

        System.out.println("Antigo rating(classificacao indicativa) =  " + c.rating);
        System.out.print("Digite o novo: ");
        c.rating = scan.nextLine();

    }

    void create() {

        try {

            RandomAccessFile arq = new RandomAccessFile("conteudos.bin", "rw");

            Conteudo c = new Conteudo();

            byte[] ba;

            // Pega o id a ser utilizado do inicio do arquivo
            int id = readIdBeginning(arq) + 1;

            // Recebe os dados digitados pelo usuario
            c.id = id;
            System.out.print("Digite o title(titulo): ");
            c.title = scan.nextLine();
            System.out.print("Digite o cast(elenco): ");
            c.cast = scan.nextLine();
            System.out.print("Digite a date_added(data que foi adicionado): ");
            c.date_added = c.dateFormat.parse(scan.nextLine());
            System.out.print("Digite o release_year(ano de lançamento): ");
            c.release_year = Integer.parseInt(scan.nextLine());
            System.out.print("Digite o rating(classificação indicativa - como TV-MA): ");
            c.rating = scan.nextLine();

            arq.seek(arq.length()); // Coloca o ponteiro do arquivo na posicao recebida

            ba = c.toByteArray();
            arq.writeInt(ba.length);
            arq.write(ba);

            writeIdBeginning(arq, c.id);

            System.out.print("O id do registro eh " + c.id);

            arq.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    void read() {

        int id = -1;
        long pos;
        Conteudo c = new Conteudo();

        System.out.print("Digite o id do registro: ");
        try {
            id = Integer.parseInt(scan.nextLine());
        } catch (Exception e) {
            e.printStackTrace();
        }

        pos = find(id, c);

        if (pos == 0) {
            System.out.println("Registro de id = " + id + " nao exsite!");
        } else {
            System.out.println(c.toString());
            System.out.println(" ");
        }

    }

    void update() {
        byte[] ba;
        long pos;
        int id, tam, x;

        Conteudo c = new Conteudo();

        try {
            RandomAccessFile arq = new RandomAccessFile("conteudos.bin", "rw");

            System.out.print("Digite o id do registro: ");
            id = Integer.parseInt(scan.nextLine());

            pos = find(id, c);

            if (pos != 0) {
                arq.seek(pos - 4); // Coloca o ponteiro para ler o registro incluindo seu tamanho
                tam = arq.readInt();
                ba = new byte[tam];
                arq.read(ba);
                c.fromByteArray(ba);

                System.out.println("Registro encontrado: ");
                System.out.println(c.toString());

                System.out.println("0 - Sair");
                System.out.println("1 - Tudo");
                System.out.println("2 - Title(titulo)");
                System.out.println("3 - Cast(elenco)");
                System.out.println("4 - Date added(Data em que foi adicionado)");
                System.out.println("5 - Release year(Ano de lancamento)");
                System.out.println("6 - Rating(classificao indicativa)");
                System.out.print("Digite o que gostaria de alterar: ");
                x = Integer.parseInt(scan.nextLine());

                switch (x) {

                    case 0:
                        break;

                    case 1:
                        changeTitle(c);
                        changeCast(c);
                        changeDate(c);
                        changeYear(c);
                        changeRating(c);
                        break;

                    case 2:
                        changeTitle(c);
                        break;

                    case 3:
                        changeCast(c);
                        break;

                    case 4:
                        changeDate(c);
                        break;

                    case 5:
                        changeYear(c);
                        break;

                    case 6:
                        changeRating(c);
                        break;

                    default:
                        System.out.println("\nERRO!");
                        break;
                }

                System.out.println("Registro atualizado: ");
                System.out.println(c.toString());

                ba = c.toByteArray();

                if (ba.length <= tam) {
                    arq.seek(pos);
                    arq.write(ba);
                } else { // Se for maior, o antigo registro deve ser apagado
                    delete(c.id);
                    arq.seek(arq.length());
                    tam = ba.length;
                    arq.writeInt(tam);
                    arq.write(ba);
                }

            } else {
                System.out.println("Registro de id = " + id + " nao exsite!");
            }

            arq.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    boolean delete(int id) {

        byte[] ba;
        long pos = 0;
        boolean result = false;

        Conteudo c = new Conteudo();

        try {

            RandomAccessFile arq = new RandomAccessFile("conteudos.bin", "rw");

            pos = find(id, c);

            if (pos != 0) {
                c.lapide = 1;
                arq.seek(pos);
                ba = c.toByteArray();
                arq.write(ba);
                result = true;
            }

            arq.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;

    }
}
