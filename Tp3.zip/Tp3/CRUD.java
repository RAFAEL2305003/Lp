import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.RandomAccessFile;
import java.util.*;
import java.io.IOException;

class CRUD {

    private static Scanner scan = new Scanner(System.in);

    static int readIdBeginning(RandomAccessFile arq) { // Le o ultimo id adicionado, que esta no comeco do arquivo e o
        // retorna

        int id = 0;

        try {

            arq.seek(0);
            id = arq.readInt();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return id;

    }

    static void writeIdBeginning(RandomAccessFile arq, int id) { // Escreve o id no inicio do arquivo

        try {
            arq.seek(0);
            arq.writeInt(id);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void createBin() { // Metodo para criar o arqui .bin utilizando o csv como base
        // Variável para gerar o id
        int i = 0;

        if (!new File("conteudos.bin").exists()) {

            try {

                // Abre csv para leitura e .bin para escrita
                BufferedReader br = new BufferedReader(new FileReader("Netflix.csv"));
                RandomAccessFile arq = new RandomAccessFile("conteudos.bin", "rw");

                byte[] ba;

                String line;

                // Ignora linha com os labels
                line = br.readLine();

                writeIdBeginning(arq, i);

                // Loop para ler todas as linhas do csv
                while ((line = br.readLine()) != null) {

                    arq.seek(arq.length());

                    Conteudo c = new Conteudo();

                    // Separa cada parte do conteudo
                    String[] values = line.split(";");

                    // Coloca no objeto conteudo os dados lidos
                    c.id = i;
                    c.title = values[0];
                    c.cast = values[1];
                    c.date_added = c.dateFormat.parse(values[2]);
                    c.release_year = Integer.parseInt(values[3]);
                    c.rating = values[4];

                    ba = c.toByteArray();

                    // Escreve o tamanho do resgistro antes dele
                    arq.writeInt(ba.length);

                    arq.write(ba);

                    writeIdBeginning(arq, i);

                    i++;

                }

                arq.close();
                br.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public static void menuOrdExt(OrdExterna ordExt) {
        int mode = 0;
        System.out.println("0 - Voltar");
        System.out.println("1 - Intercalacao Comum");
        System.out.println("2 - Intercalacao com bloco de tamanho variavel");
        System.out.println("3 - Intercalacao com Heap");
        System.out.print("Digite a opcao desejada: ");
        try {
            mode = Integer.parseInt(scan.nextLine());
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (mode != 0) {
            if (mode > 0 && mode < 3) {
                ordExt.interBalanceada(mode);
            } else if (mode == 3) {
                Heap heap = new Heap();
                heap.createTmps();
            } else {
                System.out.println("\nERRO!");
            }
        }
    }

    public static void menuSequencial(ListaInvertida Li) {

        OrdExterna ordExt = new OrdExterna(scan);

        String aux;
        int x;

        do {

            System.out.println("\n0 - Sair");
            System.out.println("1 - Create");
            System.out.println("2 - Read");
            System.out.println("3 - Update");
            System.out.println("4 - Delete");
            System.out.println("5 - Ordenacao Externa");
            System.out.print("Digite a opcao desejada: ");

            aux = scan.nextLine();
            x = Integer.parseInt(aux);

            switch (x) {

                case 0:
                    break;

                case 1:
                    ordExt.create();
                    break;

                case 2:
                    ordExt.read();
                    break;

                case 3:
                    ordExt.update();
                    break;

                case 4:
                    int id;
                    boolean result;
                    try {
                        System.out.print("\nDigite o id do registro: ");
                        id = Integer.parseInt(scan.nextLine());
                        result = ordExt.delete(id);
                        if (result) {
                            System.out.println("\nRegistro deletado com sucesso!");
                        } else {
                            System.out.println("\nRegistro de id = " + id + " nao encontrado!");
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    break;

                case 5:
                    menuOrdExt(ordExt);
                    break;
                default:
                    System.out.println("\nERRO!");
                    break;
            }
            if (x == 1 || x == 3 || x == 4) {
                Li.WriteInFirstInvertedList();
                Li.WriteInSecondInvertedList();
            }

        } while (x != 0);
    }

    public static void menuLista(ListaInvertida Li) {

        int x;

        Li.WriteInFirstInvertedList();
        Li.WriteInSecondInvertedList();

        Li.interface1();
        System.out.print("Por favor, selecione uma alternativa:");
        x = Integer.valueOf(scan.nextLine());

        switch (x) {
            case 1:
                Li.interface2();
                System.out.print("Por favor, selecione uma alternativa:");

                x = Integer.valueOf(scan.nextLine());

                if (x == 1) {
                    Li.interface3();
                    System.out.print("Por favor, selecione uma alternativa:");
                    x = Integer.valueOf(scan.nextLine());

                    if (x == 1)
                        Li.searchInFirstInvertedList("TV-MA");
                    else if (x == 2)
                        Li.searchInFirstInvertedList("TV-14");
                    else if (x == 3)
                        Li.searchInFirstInvertedList("PG-13");
                    else if (x == 4)
                        Li.searchInFirstInvertedList("TV-PG");
                    else if (x == 5)
                        Li.searchInFirstInvertedList("TV-Y7");
                    else if (x == 6)
                        Li.searchInFirstInvertedList("NC-17");
                    else
                        System.out.println("Erro!");

                } else if (x == 2) {
                    Li.interface4();
                    System.out.print(
                            "Por favor, selecione uma alternativa (Digitando alguma das opcoes acima):");
                    x = Integer.valueOf(scan.nextLine());

                    if (x == 2021 || x == 2020 || x == 2019 || x == 2018 || x == 2017 || x == 2016)
                        Li.searchInSecondInvertedList(x);
                    else
                        System.out.println("Erro!");

                } else {
                    System.out.println("Erro!");
                }

                break;
            case 2:
                System.out.print("\nLista invertida de classificacao:");
                Li.interface3();
                System.out.println();

                System.out.print("Digite sua opcao:");
                x = Integer.valueOf(scan.nextLine());

                String tmp = "";
                boolean resp;

                if (x == 1 || x == 2 || x == 3 || x == 4 || x == 5 || x == 6) {
                    if (x == 1)
                        tmp = "TV-MA";
                    else if (x == 2)
                        tmp = "TV-14";
                    else if (x == 3)
                        tmp = "PG-13";
                    else if (x == 4)
                        tmp = "TV-PG";
                    else if (x == 5)
                        tmp = "TV-Y7";
                    else if (x == 6)
                        tmp = "NC-17";

                    System.out.print("\nLista invertida de ano de lancamento:");
                    Li.interface4();

                    System.out.println();
                    System.out.print(
                            "Por favor, selecione uma alternativa (Digitando alguma das opcoes acima):");
                    x = Integer.valueOf(scan.nextLine());

                    if (x == 2021 || x == 2020 || x == 2019 || x == 2018 || x == 2017
                            || x == 2016) {
                        resp = Li.searchInTwoInvertedLists(x, tmp);
                        if (!resp)
                            System.out.println(
                                    "Nenhum conteudo presente na lista apresenta a classificacao "
                                            + tmp
                                            + " , no ano de lancamento " + x);
                    } else
                        System.out.println("Erro!");
                } else {
                    System.out.println("Erro!");
                }

                tmp = null;
                break;
            default:
                break;
        }

    }

    public static void menuIndexado(ListaInvertida Li) {

        String aux;
        int x;

        System.out.println("\n0 - Sair");
        System.out.println("1 - Hashing");
        System.out.println("2 - Lista invertida");
        System.out.print("Digite a opcao desejada: ");

        x = Integer.valueOf(scan.nextLine());
        switch (x) {
            case 0:

                break;

            case 1:
                Hashing hash = new Hashing(scan);
                hash.createIndex();

                do {
                    System.out.println("\n0 - Sair");
                    System.out.println("1 - Create");
                    System.out.println("2 - Read");
                    System.out.println("3 - Update");
                    System.out.println("4 - Delete");
                    System.out.print("Digite a opcao desejada: ");

                    aux = scan.nextLine();
                    x = Integer.parseInt(aux);

                    switch (x) {
                        case 0:

                            break;

                        case 1:
                            hash.create();
                            break;

                        case 2:
                            hash.read();
                            break;

                        case 3:
                            hash.update();
                            break;

                        case 4:
                            int id;
                            boolean result;
                            try {
                                System.out.print("\nDigite o id do registro: ");
                                id = Integer.parseInt(scan.nextLine());
                                result = hash.delete(id);
                                if (result) {
                                    System.out.println("\nRegistro deletado com sucesso!");
                                } else {
                                    System.out.println("\nRegistro de id = " + id + " nao encontrado!");
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            break;

                        default:
                            break;
                    }
                } while (x != 0);
                break;

            case 2:

                break;

            default:
                break;
        }
    }

    public static void menuCasamento() {

        String aux;
        int x;

        do {
            System.out.println("\n0 - Voltar");
            System.out.println("1 - KMP");
            System.out.println("2 - Rabin-Karp");
            System.out.print("Digite a opcao desejada: ");

            aux = scan.nextLine();
            x = Integer.parseInt(aux);

            switch (x) {
                case 0:

                    break;

                case 1:
                    KMP kmp = new KMP();
                    kmp.busca();
                    break;

                case 2:
                    RabinKarp rk = new RabinKarp();
                    rk.busca();
                    break;

                default:
                    System.out.println("\nERRO!");
                    break;
            }
        } while (x != 0);

    }

    static double calcTaxa(String f) {
        String file = "Netflix.csv";
        File filex = new File(file);

        long size1 = filex.length();

        filex = new File(f);

        long size2 = filex.length();

        return (double) size2 / (double) size1;
    }

    static double calcFator(String f) {
        String file = "Netflix.csv";
        File filex = new File(file);

        long size1 = filex.length();

        filex = new File(f);

        long size2 = filex.length();

        return (double) size1 / (double) size2;
    }

    public static void menuCompressao() {

        String aux;
        int x;
        boolean exists = false;

        String file = "Netflix.csv", str = "";

        try (FileReader fileReader = new FileReader(file)) {
            int character;
            while ((character = fileReader.read()) != -1) {
                char c = (char) character;
                str += c;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        Huffman h = new Huffman();
        Lzw lzw = new Lzw();

        Huffman.Table t = new Huffman.Table();
        Huffman.List l = new Huffman.List();

        t.fillTable(str);
        l.fillList(t.table, l);

        double res = 0;

        Huffman.Node tree = l.assembleTree(l);

        do {
            System.out.println("\n0 - Voltar");
            System.out.println("1 - Comprimir");
            System.out.println("2 - Descomprimir");
            System.out.print("Digite a opcao desejada: ");

            aux = scan.nextLine();
            x = Integer.parseInt(aux);

            switch (x) {
                case 0:

                    break;

                case 1:
                    long tempoInicial = System.currentTimeMillis();
                    lzw.compress(str);
                    System.out
                            .println("O metodo foi executado em " + (System.currentTimeMillis() - tempoInicial)
                                    + " ms\n");
                    tempoInicial = System.currentTimeMillis();

                    int dc = l.heightTree(tree);
                    l.dictionary(tree, "", dc);

                    l.encode(str);

                    System.out
                            .println("O método foi executado em " + (System.currentTimeMillis() - tempoInicial)
                                    + " ms");
                    res = calcTaxa("NetflixCompressaoLzwX.bin");
                    System.out.println("Taxa de compressao Lzw = " + res);
                    res = calcFator("NetflixCompressaoLzwX.bin");
                    System.out.println("Fator de compressao Lzw = " + res);

                    res = calcTaxa("NetflixCompressaoHuffmanX.bin");
                    System.out.println("Taxa de compressao Huffman = " + res);
                    res = calcFator("NetflixCompressaoHuffmanX.bin");
                    System.out.println("Fator de compressao Huffman = " + res);

                    exists = true;
                    break;

                case 2:
                    if (exists) {
                        tempoInicial = System.currentTimeMillis();
                        System.out.println("Descompressao Lzw:\n" + lzw.decompress());
                        System.out
                                .println("O metodo foi executado em " + (System.currentTimeMillis() -
                                        tempoInicial)
                                        + " ms");
                        System.out.println();
                        tempoInicial = System.currentTimeMillis();
                        System.out.println("Decompressao Huffman:\n" + h.decompress(tree));
                        System.out
                                .println("O metodo foi executado em " + (System.currentTimeMillis() - tempoInicial)
                                        + " ms");

                    } else {
                        System.out.println("Nenhuma compressao foi realizada!");
                    }
                    break;

                default:
                    System.out.println("\nERRO!");
                    break;
            }
        } while (x != 0);

    }

    public static void menuCriptografia() {
        int x;
        String aux;

        try {

            do {
                System.out.println("\n0 - Voltar");
                System.out.println("1 - Cifra de Cesar");
                System.out.println("2 - Cifra por colunas");
                System.out.println("3 - Cifra de vigenere");
                System.out.println("4 - Cifra por substituicao");
                System.out.print("Digite a opcao desejada: ");

                aux = scan.nextLine();
                x = Integer.parseInt(aux);

                switch (x) {
                    case 0:
                        break;

                    case 1:
                        CifraDeCesar cesar = new CifraDeCesar();

                        System.out.println();

                        System.out.print("Digite o valor da chave: ");
                        int chave = Integer.valueOf(scan.nextLine()), show;

                        while(chave <= 0) {
                            System.out.print("Digite o valor da chave: ");
                            chave = Integer.valueOf(scan.nextLine());
                        }

                        System.out.println();
                        System.out.print("Lendo arquivo csv...");
                        String file = "Netflix.csv", text = cesar.readFromFile(file);

                        System.out.println("\n");

                        System.out.print("Criptografando...");

                        String encrypted = cesar.criptografar(text, chave);

                        file = "CriptografiaCesar.csv";
                        cesar.writeFromFile(file, encrypted);

                        System.out.print("\nExibir texto criptografado? (1: sim, 0: nao): ");
                        show = Integer.valueOf(scan.nextLine());

                        if(show == 1) {
                            System.out.println("\nTexto criptografado:");
                            System.out.println(encrypted);
                        }

                        System.out.println();
                        System.out.print("Deseja descriptografar o arquivo? (1: sim, 0: nao): ");
                        show = Integer.valueOf(scan.nextLine());

                        if(show == 1) {
                            System.out.println("\n");
                            System.out.print("Deanriptografando...");
                            
                            String decrypted = cesar.descriptografar(encrypted, chave);

                            file = "DescriptografiaCesar.csv";
                            cesar.writeFromFile(file, decrypted);

                            System.out.print("\nExibir texto descriptografado? (1: sim, 0: nao): ");
                            show = Integer.valueOf(scan.nextLine());

                            if(show == 1) {
                                System.out.println("\nTexto descriptografado:");
                                System.out.println(decrypted);
                            }
                        }
                        break;

                    case 2:
                        CifraPorColunas colunas = new CifraPorColunas();

                        System.out.println();

                        System.out.print("Lendo arquivo csv...");
                        file = "Netflix.csv";
                        text = colunas.readFromFile(file);

                        System.out.println("\n");

                        System.out.print("Digite a chave para criptografia: ");
                        String key = scan.nextLine();

                        System.out.println();

                        System.out.print("Criptografando...");

                        encrypted = colunas.encrypt(text, key);

                        file = "CriptografiaC.csv";
                        colunas.writeFromFile(file, encrypted);

                        System.out.print("\nExibir texto criptografado? (1: sim, 0: nao): ");
                        show = Integer.valueOf(scan.nextLine());

                        if(show == 1) {
                            System.out.println("\nTexto criptografado:");
                            System.out.println(encrypted);
                        }

                        System.out.println();
                        System.out.print("Deseja descriptografar o arquivo? (1: sim, 0: nao): ");
                        show = Integer.valueOf(scan.nextLine());

                        if(show == 1) {
                            System.out.println("\n");
                            System.out.print("Descriptografando...");
                            
                            String decrypted = colunas.decrypt(encrypted, key);

                            file = "DescriptografiaC.csv";
                            colunas.writeFromFile(file, decrypted);

                            System.out.print("\nExibir texto descriptografado? (1: sim, 0: nao): ");
                            show = Integer.valueOf(scan.nextLine());

                            if(show == 1) {
                                System.out.println("\nTexto descriptografado:");
                                System.out.println(decrypted);
                            }
                        }
                        break;
                    
                    case 3:
                        CifraDeVigenere vigenere = new CifraDeVigenere();
                        
                        System.out.println();

                        Alphabet[] v = new Alphabet[26];

                        String decrypted = "";
                        text = "aAbBcCdDeEfFgGhHiIjJkKlLmMnNoOpPqQrRsStTuUvVwWxXyYzZ";
                        encrypted = "";

                        file = "Netflix.csv";
                        char[] txt = text.toCharArray();

                        for (int i = 0; i < v.length; i++) {
                            v[i] = new Alphabet();
                        }

                        for (int i = 0; i < txt.length; i += 2) {
                            v[i / 2].index = i / 2;
                            v[i / 2].data[0] = txt[i];
                            v[i / 2].data[1] = txt[i + 1];
                        }
                        
                        text = "";
                        System.out.print("Lendo arquivo csv...");
                        text = vigenere.readFromFile(file);

                        System.out.println("\n");

                        System.out.print("Digite a chave para a criptografia: ");
                        key = scan.nextLine();
                        System.out.println();

                        int[] arrText = vigenere.processStr(v, text);
                        int[] arrKey = vigenere.processStr(v, key);

                        System.out.print("Criptografando...");

                        encrypted = vigenere.encrypt(arrText, arrKey, v, text);

                        file = "CriptografiaV.csv";
                        vigenere.writeFromFile(file, encrypted);

                        System.out.print("\nExibir texto criptografado? (1: sim, 0: nao): ");
                        show = Integer.valueOf(scan.nextLine());

                        if(show == 1) {
                            System.out.println("\nTexto criptografado:");
                            System.out.println(encrypted);
                        }

                        System.out.println();
                        System.out.print("Deseja descriptografar o arquivo? (1: sim, 0: nao): ");
                        show = Integer.valueOf(scan.nextLine());

                        if(show == 1) {
                            System.out.println("\n");
                            System.out.print("Descriptografando...");

                            decrypted = vigenere.decrypt(arrText, arrKey, v, encrypted);

                            file = "DescriptografiaV.csv";
                            vigenere.writeFromFile(file, decrypted);

                            System.out.print("\nExibir texto descriptografado? (1: sim, 0: nao): ");
                            show = Integer.valueOf(scan.nextLine());

                            if(show == 1) {
                                System.out.println("\nTexto descriptografado:");
                                System.out.println(decrypted);
                            }
                        }
                        break;

                    case 4:
                        CifraPorSubstituicao substituicao = new CifraPorSubstituicao();

                        System.out.println();
                        
                        String txt1 = "abcdefghijklmABCDEFGHIJKLM", txt2 = "nopqrstuvwxyzNOPQRSTUVWXYZ";
                        char[] v1 = txt1.toCharArray(), v2 = txt2.toCharArray();

                        file = "Netflix.csv";
                        text = encrypted = decrypted = "";
                        System.out.print("Lendo arquivo csv...");
                        text = substituicao.readFromFile(file);

                        System.out.println("\n");

                        System.out.print("Criptografando...");
                        file = "CriptografiaS.csv";
                        encrypted = substituicao.criptografarEdescriptografar(text, v1, v2);
                        substituicao.writeFromFile(file, encrypted);
                        
                        System.out.print("\nExibir texto criptografado? (1: sim, 0: nao): ");
                        show = Integer.valueOf(scan.nextLine());

                        if(show == 1) {
                            System.out.println("\nTexto criptografado:");
                            System.out.println(encrypted);
                        }

                        System.out.println();
                        System.out.print("Deseja descriptografar o arquivo? (1: sim, 0: nao): ");
                        show = Integer.valueOf(scan.nextLine());

                        if(show == 1) {
                            System.out.println("\n");

                            System.out.print("Descriptografando...");
                            file = "DescriptografiaS.csv";
                            decrypted = substituicao.criptografarEdescriptografar(encrypted, v1, v2);
                            substituicao.writeFromFile(file, decrypted);

                            System.out.print("\nExibir texto descriptografado? (1: sim, 0: nao): ");
                            show = Integer.valueOf(scan.nextLine());

                            if(show == 1) {
                                System.out.println("\nTexto descriptografado:");
                                System.out.println(decrypted);
                            }
                        }
                        break;

                    default:
                        System.out.println("\nERRO!");
                        break;
                }
            } while (x != 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    static void menu() { // Mostra as opcoes ao usuario e faz a tarefa escolhida

        int x = 0;

        createBin();

        ListaInvertida Li = new ListaInvertida();

        do {

            System.out.println("\n0 - Sair");
            System.out.println("1 - Arquivo Sequencial");
            System.out.println("2 - Arquivo Indexado");
            System.out.println("3 - Compressao de Dados");
            System.out.println("4 - Casamento de Padroes");
            System.out.println("5 - Criptografia");
            System.out.print("Digite a opcao desejada: ");

            String aux = scan.nextLine();
            x = Integer.parseInt(aux);

            switch (x) {

                case 0:
                    scan.close();
                    break;

                case 1:
                    menuSequencial(Li);
                    break;

                case 2:
                    menuIndexado(Li);
                    break;

                case 3:
                    menuCompressao();
                    break;

                case 4:
                    menuCasamento();
                    break;

                case 5:
                    menuCriptografia();
                    break;

                default:
                    System.out.println("\nERRO!");
                    break;
            }
        } while (x != 0);
    }
}
