import java.io.RandomAccessFile;
import java.math.BigInteger;
import java.util.*;

class RabinKarp {

    static int R = 256, M, nCmp = 0;
    static long RM, Q;
    static int linha;

    static Scanner scan = new Scanner(System.in);

    static private long hash(String s, int M) {
        long h = 0;
        for (int j = 0; j < M; j++)
            h = (h * R + s.charAt(j)) % Q;
        return h;
    }

    private static long longRandomPrime() {
        BigInteger prime = BigInteger.probablePrime(31, new Random());
        return prime.longValue();
    }

    static private int search(String txt, String pd, long hashPadrao) {
        int N = txt.length();
        long txtHash = hash(txt, M);
        nCmp++;
        if (hashPadrao == txtHash && check(txt, pd, 0)) // casamento
            return 0;
        for (int i = 1; i <= N - M; i++) {
            txtHash = (txtHash + Q - RM * txt.charAt(i - 1) % Q) % Q;
            txtHash = (txtHash * R + txt.charAt(i + M - 1)) % Q;
            nCmp++;
            if (hashPadrao == txtHash)
                if (check(txt, pd, i))
                    return i; // casamento
        }
        return N; // nenhum casamento
    }

    static private boolean check(String txt, String pd, int i) {
        for (int j = 0; j < M; j++)
            if (pd.charAt(j) != txt.charAt(i + j))
                return false;
        return true;
    }

    public void busca() {
        linha = 1;

        Q = longRandomPrime();

        try {

            String padrao;
            int tam, resp;
            byte[] ba;
            long hashPadrao;
            boolean found = false;
            Conteudo c = new Conteudo();

            RandomAccessFile arq = new RandomAccessFile("conteudos.bin", "rw");

            arq.seek(4);

            System.out.print("Digite o padrao a ser encontrado: ");
            padrao = scan.nextLine();

            M = padrao.length();

            for (int i = 1; i <= M - 1; i++) // calcula R^(M-1)%Q
                RM = (R * RM) % Q;
            hashPadrao = hash(padrao, M);

            while (arq.getFilePointer() != arq.length() && !found) {

                tam = arq.readInt();
                ba = new byte[tam];
                arq.read(ba);
                c.fromByteArray(ba);

                String txt = c.toStringNoSpace();

                resp = search(txt, padrao, hashPadrao);

                if (resp != txt.length()) {
                    System.out.println("Encontrado na linha " + linha + ", index " + (resp));
                    System.out.println("Numero de comparacoes =  " + nCmp);
                    found = true;
                }

                linha++;
            }

            if (!found) {
                System.out.println("Padrao ausente!");
            }

            arq.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
