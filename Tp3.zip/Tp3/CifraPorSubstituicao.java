import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CifraPorSubstituicao {
    // Verificando se um caracter eh letra
    public static boolean isLetter(char c) {
        return ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'));
    }

    // Metodo para ler arquivos
    public String readFromFile(String file) {
        String str = "";
        try (FileReader fileReader = new FileReader(file)) {
            int character;
            while ((character = fileReader.read()) != -1) {
                char s = (char) character;
                str += s;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return str;
    }

    // Metodo para escrever em arquivos
    public void writeFromFile(String file, String encrypted) {
        try (FileWriter fileWriter = new FileWriter(file)) {
            fileWriter.write(encrypted);
            System.out.println("\nResultados foram escritos em " + file);
        } catch (IOException e) {
            System.out.println("Erro ao escrever no arquivo: " + e.getMessage());
        }
    }

    // Metodo para procurar certo elemento no array e retornar verdadeiro caso ele exista no mesmo
    public boolean search(char[] arr, char c) {
        boolean res = false;
        for (int i = 0; !res && i < arr.length; i++) {
            if(arr[i] == c) {
                res = true;
            }
        }
        return res;
    }
    
    // Metodo para procurar certo elemento no array e retornar a posicao dele caso exista no mesmo
    public int searchI(char[] arr, char c) {
        int pos = 0;
        for (int i = 0; i < arr.length; i++) {
            if(arr[i] == c) {
                pos = i;
                break;
            }
        }
        return pos;
    }

    // Função para criptografar e descriptografar o array
    public String criptografarEdescriptografar(String in, char[] arr1, char[] arr2) {
        int x;
        char c;
        String result = "";

        for (int i = 0; i < in.length(); i++) {
            c = in.charAt(i);
            if(isLetter(c)) {
                if(search(arr1, c)) {
                    x = searchI(arr1, c);
                    result += arr2[x];
                } else {
                    x = searchI(arr2, c);
                    result += arr1[x];
                }
            } else {
                result += c;
            }
        }

        return result;
    }
}