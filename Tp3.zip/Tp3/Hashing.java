import java.io.File;
import java.io.RandomAccessFile;
import java.util.Scanner;

public class Hashing {

    int regPorBuc = 277;
    int tamBuc = regPorBuc * 12 + 8;

    static Scanner scan;

    public Hashing(Scanner s) {
        scan = s;
    }

    static int readIdBeginning(RandomAccessFile arq) { // Le o ultimo id adicionado, que esta no comeco do arquivo e o
        // retorna

        int id = 0;

        try {

            arq.seek(0);
            id = arq.readInt();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return id;

    }

    static void writeIdBeginning(RandomAccessFile arq, int id) { // Escreve o id no inicio do arquivo

        try {
            arq.seek(0);
            arq.writeInt(id);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    long calcHash(int id) {
        int pd = 0;
        try {
            RandomAccessFile dir = new RandomAccessFile("diretorio.bin", "rw");
            dir.seek(0);
            pd = dir.readInt();

            dir.close();
        } catch (Exception e) {
            // TODO: handle exception
        }
        return ((long) ((id % (Math.pow(2, pd))) * 8 + 4));
    }

    void inicializaBucket(RandomAccessFile buc, long pos, int pb) { // Preenche um novo bucket
        int i;
        try {
            buc.seek(pos);
            buc.writeInt(pb);
            buc.writeInt(0);
            i = 0;
            while (i < regPorBuc) {
                buc.writeInt(-1);
                buc.writeLong(-1);
                i++;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    void reposicionar(RandomAccessFile dir, RandomAccessFile buc, long posBucR, long hash, int pb) { // Reposiciona as
                                                                                                     // chaves nos
                                                                                                     // buckets

        int i, id;
        long posBuc, posRegBuc, posReg, posHash = 4;
        try {

            // Atualiza a profundidade do bucket
            buc.seek(posBucR);
            buc.writeInt(pb);
            buc.readInt();
            posBuc = posBucR;
            i = 0;

            // Atualiza o bucket para o qual certa posicao do diretorio aponta
            boolean atualizaPos = false;
            while (!atualizaPos) {
                id = buc.readInt();
                posReg = buc.readLong();
                posHash = ((calcHash(id) - 4) / 8) * tamBuc;
                if (posHash != posBucR) {
                    dir.seek(calcHash(id));
                    dir.writeLong(posHash);
                    buc.seek(posHash);
                    buc.writeInt(pb);
                    atualizaPos = true;
                }
            }

            // Atualiza a posicao das chaves
            buc.seek(posBucR + 8);
            while (posBuc < (posBucR + tamBuc) && (buc.getFilePointer() != buc.length())) {
                posRegBuc = buc.getFilePointer();
                id = buc.readInt();
                posReg = buc.readLong();
                posBuc = buc.getFilePointer();
                if (id != -1) {

                    dir.seek(calcHash(id));
                    posHash = dir.readLong();

                    if (posHash != posBucR) {
                        inserir(id, posReg, dir, buc);
                        i++;
                        buc.seek(posRegBuc);
                        buc.writeInt(-1);
                        buc.writeLong(-1);
                        buc.seek(posBucR + 4);
                        buc.writeInt(regPorBuc - i);
                    }
                }
                buc.seek(posBuc);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    void quebra(RandomAccessFile dir, int pb, RandomAccessFile buc, long posBucQ, int id) {

        try {
            dir.seek(0);
            int pd = dir.readInt();
            // Calcula a quanidade de novas posicoes necessaras no diretorio
            int i, n = (int) Math.pow(2, pd);
            long posBuc;

            // Aumenta a profundidade do diretorio
            pd++;
            dir.seek(0);
            dir.writeInt(pd);
            dir.seek(dir.length());
            // Cria novos buckets
            for (i = 0; i < n; i++) {
                posBuc = buc.length();
                dir.writeLong(tamBuc * i);
                inicializaBucket(buc, posBuc, -1);
            }

            // Reposiciona as chaves
            reposicionar(dir, buc, posBucQ, calcHash(id), pb);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    void inserir(int id, long posReg, RandomAccessFile dir, RandomAccessFile buc) {
        int pd, pb, quantidadeReg, idAux;
        long posBuc, posRegBuc, hash;

        try {
            // Calcula o hash com o id e indica o bucket em que devera ser escrito
            dir.seek(0);
            pd = dir.readInt();
            hash = calcHash(id);
            dir.seek(hash);
            posBuc = dir.readLong();

            buc.seek(posBuc);
            // Le a profundidade do bucket
            pb = buc.readInt();
            // Le a quantidade de registros inseridos
            quantidadeReg = buc.readInt();
            if (quantidadeReg < regPorBuc) { // Entra caso o bucket nao esteja cheio

                posRegBuc = buc.getFilePointer();
                idAux = buc.readInt();
                while (idAux != -1) { // Procura por uma posicao vazia
                    buc.readLong();
                    posRegBuc = buc.getFilePointer();
                    idAux = buc.readInt();
                }

                // Posiciona na posicao vazia e salva o registro nessa posicao
                buc.seek(posRegBuc);
                buc.writeInt(id);
                buc.writeLong(posReg);
                buc.seek(posBuc + 4);
                // Atualiza o numero de registros no bucket
                buc.writeInt(quantidadeReg + 1);
            } else {
                if (pb == pd) { // Entra se o bucket estiver cheio e as profundiades forem iguais
                    quebra(dir, pb + 1, buc, posBuc, id);
                    inserir(id, posReg, dir, buc);
                } else {// Entra se o bucket estiver cheio e as profundiades forem diferentes
                    reposicionar(dir, buc, posBuc, hash, pb + 1);
                    inserir(id, posReg, dir, buc);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void createIndex() { // Cria um arquivo de indice com hashing extensivel

        if (!new File("diretorio.bin").exists() || !new File("bucket.bin").exists()) {

            try {
                RandomAccessFile arq = new RandomAccessFile("conteudos.bin", "rw");
                RandomAccessFile dir = new RandomAccessFile("diretorio.bin", "rw");
                RandomAccessFile buc = new RandomAccessFile("bucket.bin", "rw");
                Conteudo c = new Conteudo();
                byte[] ba;
                int tam, pd;
                long posReg;

                pd = 0;

                arq.seek(4);
                dir.seek(0);
                buc.seek(0);

                // Escreve a profundidade do diretorio e aponta bara o primeiro bucket
                dir.writeInt(0);
                dir.writeLong(0);
                inicializaBucket(buc, 0, pd);

                while (arq.getFilePointer() != arq.length()) {

                    // le o resgistro do arquivo e salva sua posicao
                    posReg = arq.getFilePointer();
                    tam = arq.readInt();
                    ba = new byte[tam];
                    arq.read(ba);

                    c.fromByteArray(ba);

                    if (c.getLapide() == 0) { // Se nao estiver apagado insere o id no arquivo de indice
                        inserir(c.getId(), posReg, dir, buc);
                    }

                }

                arq.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    long find(int id, Conteudo c) { // Encotra a posicao do registro com certo id e retorna sua posicao

        byte[] ba;
        int tam, i;
        long posBuc, posReg, posRegBuc = 0;
        boolean found = false;

        try {

            RandomAccessFile arq = new RandomAccessFile("conteudos.bin", "rw");
            RandomAccessFile dir = new RandomAccessFile("diretorio.bin", "rw");
            RandomAccessFile buc = new RandomAccessFile("bucket.bin", "rw");

            dir.seek(calcHash(id));

            posBuc = dir.readLong();

            buc.seek(posBuc + 8);

            i = 0;

            while (i < regPorBuc && !found) {
                int idLido = buc.readInt();
                posReg = buc.readLong();
                if (idLido == id) {
                    posRegBuc = (buc.getFilePointer() - 12);
                    found = true;
                    arq.seek(posReg);

                    tam = arq.readInt();
                    ba = new byte[tam];
                    arq.read(ba);
                    c.fromByteArray(ba);
                }
                i++;
            }

            if (!found) {
                posRegBuc = 0;
            }

            arq.close();
            dir.close();
            buc.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return posRegBuc;
    }

    void create() {

        try {

            RandomAccessFile arq = new RandomAccessFile("conteudos.bin", "rw");
            RandomAccessFile dir = new RandomAccessFile("diretorio.bin", "rw");
            RandomAccessFile buc = new RandomAccessFile("bucket.bin", "rw");

            Conteudo c = new Conteudo();

            byte[] ba;

            long posReg;

            // Pega o id a ser utilizado do inicio do arquivo
            int id = readIdBeginning(arq) + 1;

            // Recebe os dados digitados pelo usuario
            c.id = id;
            System.out.print("Digite o title(titulo): ");
            c.title = scan.nextLine();
            System.out.print("Digite o cast(elenco): ");
            c.cast = scan.nextLine();
            System.out.print("Digite a date_added(data que foi adicionado): ");
            c.date_added = c.dateFormat.parse(scan.nextLine());
            System.out.print("Digite o release_year(ano de lançamento): ");
            c.release_year = Integer.parseInt(scan.nextLine());
            System.out.print("Digite o rating(classificação indicativa - como TV-MA): ");
            c.rating = scan.nextLine();

            arq.seek(arq.length()); // Coloca o ponteiro do arquivo na posicao recebida

            posReg = arq.getFilePointer();

            ba = c.toByteArray();
            arq.writeInt(ba.length);
            arq.write(ba);

            writeIdBeginning(arq, c.id);

            inserir(c.getId(), posReg, dir, buc);

            System.out.print("O id do registro eh " + c.id);

            arq.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    void read() {

        try {

            int id = -1;
            long posReg;
            Conteudo c = new Conteudo();

            System.out.print("Digite o id do registro: ");

            id = Integer.parseInt(scan.nextLine());

            if (id >= 0) {
                posReg = find(id, c);

                if (posReg != 0) {
                    System.out.println(c.toString());
                    System.out.println(" ");
                } else {
                    System.out.println("Registro de id = " + id + " nao exsite!");
                }
            } else {
                System.out.println("Registro de id = " + id + " nao exsite!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    boolean deleteBin(int id) {

        byte[] ba;
        long pos = 0;
        boolean result = false;

        Conteudo c = new Conteudo();

        try {

            RandomAccessFile arq = new RandomAccessFile("conteudos.bin", "rw");

            pos = find(id, c);

            if (pos != 0) {
                c.lapide = 1;
                arq.seek(pos);
                ba = c.toByteArray();
                arq.write(ba);
                result = true;
            }

            arq.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;

    }

    boolean delete(int id) {

        byte[] ba;
        long posRegBuc = 0, pos, posBuc;
        int qRegBuc = 0;
        boolean result = false;

        Conteudo c = new Conteudo();

        try {

            RandomAccessFile arq = new RandomAccessFile("conteudos.bin", "rw");
            RandomAccessFile dir = new RandomAccessFile("diretorio.bin", "rw");
            RandomAccessFile buc = new RandomAccessFile("bucket.bin", "rw");

            posRegBuc = find(id, c);

            if (posRegBuc != 0) {

                dir.seek(calcHash(id));
                posBuc = dir.readLong();

                buc.seek(posRegBuc + 4);
                pos = buc.readLong();

                c.lapide = 1;
                arq.seek(pos);
                ba = c.toByteArray();
                arq.write(ba);

                buc.seek(posRegBuc);
                buc.writeInt(-1);
                buc.writeLong(-1);

                buc.seek(posBuc + 4);
                qRegBuc = buc.readInt();
                buc.seek(posBuc + 4);
                buc.writeInt(qRegBuc - 1);

                result = true;
            }

            arq.close();
            dir.close();
            buc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;

    }

    private static void changeTitle(Conteudo c) { // Altera o titulo do conteudo

        System.out.println("Antigo title(titulo) =  " + c.title);
        System.out.print("Digite o novo: ");
        c.title = scan.nextLine();

    }

    private static void changeCast(Conteudo c) { // Altera o elenco do conteudo

        System.out.println("Antigo cast(elenco) =  " + c.cast);
        System.out.print("Digite o novo: ");
        c.cast = scan.nextLine();

    }

    private static void changeDate(Conteudo c) { // Altera a data do conteudo
        try {
            System.out.println("Data antiga =  " + c.dateFormat.format(c.date_added));
            System.out.print("Digite a nova: ");
            c.date_added = c.dateFormat.parse(scan.nextLine());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static void changeYear(Conteudo c) { // Altera o ano do conteudo
        try {
            System.out.println("Antigo ano =  " + c.release_year);
            System.out.print("Digite o novo: ");
            c.release_year = Integer.parseInt(scan.nextLine());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private static void changeRating(Conteudo c) { // Altera a classificacao do conteudo

        System.out.println("Antigo rating(classificacao indicativa) =  " + c.rating);
        System.out.print("Digite o novo: ");
        c.rating = scan.nextLine();

    }

    void update() {
        byte[] ba;
        long posRegBuc, pos;
        int id, tam, x;

        Conteudo c = new Conteudo();

        try {
            RandomAccessFile arq = new RandomAccessFile("conteudos.bin", "rw");
            RandomAccessFile dir = new RandomAccessFile("diretorio.bin", "rw");
            RandomAccessFile buc = new RandomAccessFile("bucket.bin", "rw");

            System.out.print("Digite o id do registro: ");
            id = Integer.parseInt(scan.nextLine());

            posRegBuc = find(id, c);

            if (posRegBuc != 0) {

                buc.seek(posRegBuc + 4);
                pos = buc.readLong();

                arq.seek(pos);
                tam = arq.readInt();
                ba = new byte[tam];
                arq.read(ba);
                c.fromByteArray(ba);

                System.out.println("Registro encontrado: ");
                System.out.println(c.toString());

                System.out.println("0 - Sair");
                System.out.println("1 - Tudo");
                System.out.println("2 - Title(titulo)");
                System.out.println("3 - Cast(elenco)");
                System.out.println("4 - Date added(Data em que foi adicionado)");
                System.out.println("5 - Release year(Ano de lancamento)");
                System.out.println("6 - Rating(classificao indicativa)");
                System.out.print("Digite o que gostaria de alterar: ");
                x = Integer.parseInt(scan.nextLine());

                switch (x) {

                    case 0:
                        break;

                    case 1:
                        changeTitle(c);
                        changeCast(c);
                        changeDate(c);
                        changeYear(c);
                        changeRating(c);
                        break;

                    case 2:
                        changeTitle(c);
                        break;

                    case 3:
                        changeCast(c);
                        break;

                    case 4:
                        changeDate(c);
                        break;

                    case 5:
                        changeYear(c);
                        break;

                    case 6:
                        changeRating(c);
                        break;

                    default:
                        System.out.println("\nERRO!");
                        break;
                }

                System.out.println("Registro atualizado: ");
                System.out.println(c.toString());

                ba = c.toByteArray();

                if (ba.length <= tam) {
                    arq.seek(pos);
                    arq.write(ba);
                } else { // Se for maior, o antigo registro deve ser apagado

                    deleteBin(id);

                    pos = arq.length();
                    arq.seek(pos);
                    tam = ba.length;
                    arq.writeInt(tam);
                    arq.write(ba);

                    buc.seek(posRegBuc + 4);
                    buc.writeLong(pos);

                }

            } else {
                System.out.println("Registro de id = " + id + " nao exsite!");
            }

            arq.close();
            dir.close();
            buc.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}