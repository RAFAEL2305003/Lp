import java.io.File;
import java.io.RandomAccessFile;
import java.util.Arrays;

public class Heap {

    static class Aux {
        public Conteudo data;
        public int peso;

        public Aux(Conteudo data, int peso) {
            this.data = data;
            this.peso = peso;
        }

        public Aux() {
            this(new Conteudo(), 0);
        }
    }

    private Aux[] heap;
    private int size;
    private Aux ultimo;
    private int p;
    private static final int INITIAL_CAPACITY = 100;

    public Heap() {
        heap = new Aux[INITIAL_CAPACITY];
        size = 0;
    }

    static int readIdBeginning(RandomAccessFile arq) { // Le o ultimo id adicionado, que esta no comeco do arquivo e o
        // retorna

        int id = 0;

        try {

            arq.seek(0);
            id = arq.readInt();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return id;

    }

    static void writeIdBeginning(RandomAccessFile arq, int id) { // Escreve o id no inicio do arquivo

        try {
            arq.seek(0);
            arq.writeInt(id);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public void insert(Aux d) {
        if (size >= heap.length - 1) {
            // Redimensionar o array se estiver cheio
            heap = Arrays.copyOf(heap, heap.length * 2);
        }
        size++;
        int hole = size;
        heap[0] = d; // Sentinela

        while (d.peso <= heap[hole / 2].peso && d.data.id < heap[hole / 2].data.id) {
            heap[hole] = heap[hole / 2];
            hole /= 2;
        }
        heap[hole] = d;
    }

    public Aux findMin() {
        if (isEmpty()) {
            throw new IllegalStateException("O heap esta vazio.");
        }
        return heap[1];
    }

    public Aux deleteMin() {
        if (isEmpty()) {
            throw new IllegalStateException("O heap esta vazio.");
        }
        Aux min = heap[1];
        Aux last = heap[size--];
        int child;
        int hole = 1;

        while (hole * 2 <= size) {
            child = hole * 2;
            if (child != size && heap[child + 1].peso <= heap[child].peso) {
                if (heap[child + 1].peso == heap[child].peso) {
                    if (heap[child + 1].data.id < heap[child].data.id) {
                        child++;
                    }
                } else {
                    child++;
                }
            }
            if (last.peso > heap[child].peso) {
                heap[hole] = heap[child];
            } else if (last.peso == heap[child].peso) {
                if (last.data.id > heap[child].data.id) {
                    heap[hole] = heap[child];
                } else {
                    break;
                }
            } else {
                break;
            }
            hole = child;
        }
        heap[hole] = last;
        return min;
    }

    private static int interVariavel(boolean wich, RandomAccessFile arqTemp1, RandomAccessFile arqTemp2,
            RandomAccessFile arqTemp3, RandomAccessFile arqTemp4) { // Intercala os dados com blocos de tamanho variavel

        Conteudo c1 = new Conteudo();
        Conteudo c2 = new Conteudo();
        byte[] ba;
        int tam, q1, q2, quant = 0;
        boolean aux = true;
        boolean a1, a2;

        try {
            RandomAccessFile arqRead1;
            RandomAccessFile arqRead2;
            RandomAccessFile arqWrite1;
            RandomAccessFile arqWrite2;
            if (wich) {
                arqRead1 = arqTemp1;
                arqRead2 = arqTemp2;
                arqWrite1 = arqTemp3;
                arqWrite2 = arqTemp4;
            } else {
                arqRead1 = arqTemp3;
                arqRead2 = arqTemp4;
                arqWrite1 = arqTemp1;
                arqWrite2 = arqTemp2;
            }

            arqRead1.seek(0);
            arqRead2.seek(0);
            arqWrite1.setLength(0);
            arqWrite2.setLength(0);

            RandomAccessFile arq = arqWrite1;

            while (arqRead1.getFilePointer() != arqRead1.length() || arqRead2.getFilePointer() != arqRead2.length()) {

                a1 = a2 = false;
                q1 = q2 = 0;

                if (arqRead1.getFilePointer() == arqRead1.length()) {
                    a1 = true;
                    tam = arqRead2.readInt();
                    ba = new byte[tam];
                    arqRead2.read(ba);
                    c2.fromByteArray(ba);
                } else if (arqRead2.getFilePointer() == arqRead2.length()) {
                    a2 = true;
                    tam = arqRead1.readInt();
                    ba = new byte[tam];
                    arqRead1.read(ba);
                    c1.fromByteArray(ba);
                } else {
                    tam = arqRead1.readInt();
                    ba = new byte[tam];
                    arqRead1.read(ba);
                    c1.fromByteArray(ba);

                    tam = arqRead2.readInt();
                    ba = new byte[tam];
                    arqRead2.read(ba);
                    c2.fromByteArray(ba);
                }

                if (aux) {
                    arq = arqWrite1;
                } else {
                    arq = arqWrite2;
                }

                aux = !aux;

                while (!a1 || !a2) {

                    if (a1) {

                        while (arqRead2.getFilePointer() != arqRead2.length() && c2.getId() > q2) {

                            ba = c2.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q2 = c2.getId();
                            quant++;

                            tam = arqRead2.readInt();
                            ba = new byte[tam];
                            arqRead2.read(ba);
                            c2.fromByteArray(ba);

                        }
                        if (arqRead2.getFilePointer() == arqRead2.length()) {
                            ba = c2.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q2 = c2.getId();
                            quant++;
                        }
                        if (arqRead1.getFilePointer() == arqRead1.length()) {
                            ba = c2.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q2 = c2.getId();
                            quant++;
                        }

                        a2 = true;

                    } else if (a2) {

                        while (arqRead1.getFilePointer() != arqRead1.length() && c1.getId() > q1) {

                            ba = c1.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q1 = c1.getId();
                            quant++;

                            tam = arqRead1.readInt();
                            ba = new byte[tam];
                            arqRead1.read(ba);
                            c1.fromByteArray(ba);

                        }

                        if (arqRead1.getFilePointer() == arqRead1.length()) {
                            ba = c1.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q1 = c1.getId();
                            quant++;
                        }

                        if (arqRead2.getFilePointer() == arqRead2.length()) {
                            ba = c1.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q1 = c1.getId();
                            quant++;
                        }

                        a1 = true;
                    } else {

                        if (c1.getId() > c2.getId()) {
                            ba = c2.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q2 = c2.getId();
                            quant++;

                            if (arqRead2.getFilePointer() != arqRead2.length()) {
                                tam = arqRead2.readInt();
                                ba = new byte[tam];
                                arqRead2.read(ba);
                                c2.fromByteArray(ba);
                                if (c2.getId() < q2) {
                                    arqRead2.seek(arqRead2.getFilePointer() - tam - 4);
                                    a2 = true;
                                }
                            } else {
                                a2 = true;
                            }
                        } else {
                            ba = c1.toByteArray();
                            arq.writeInt(ba.length);
                            arq.write(ba);
                            q1 = c1.getId();
                            quant++;

                            if (arqRead1.getFilePointer() != arqRead1.length()) {
                                tam = arqRead1.readInt();
                                ba = new byte[tam];
                                arqRead1.read(ba);
                                c1.fromByteArray(ba);
                                if (c1.getId() < q1) {
                                    arqRead1.seek(arqRead1.getFilePointer() - tam - 4);
                                    a1 = true;
                                }
                            } else {
                                a1 = true;
                            }
                        }
                    }
                }
                if (aux) {
                    quant = 0;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return quant;
    }

    public void createTmps() {
        try {
            p = 0;
            ultimo = new Aux();
            int i = 0, quant = 0, qReg, cont = 0, tam;
            boolean troca;
            RandomAccessFile arq = new RandomAccessFile("conteudos.bin", "rw");
            RandomAccessFile fileTmp1 = new RandomAccessFile("tmp1.bin", "rw");
            RandomAccessFile fileTmp2 = new RandomAccessFile("tmp2.bin", "rw");
            RandomAccessFile fileTmp3 = new RandomAccessFile("tmp3.bin", "rw");
            RandomAccessFile fileTmp4 = new RandomAccessFile("tmp4.bin", "rw");

            arq.seek(4);

            while (i < INITIAL_CAPACITY) {
                Conteudo c = new Conteudo();
                if (arq.getFilePointer() != arq.length()) {
                    tam = arq.readInt();
                    byte[] ba = new byte[tam];
                    arq.read(ba);
                    c.fromByteArray(ba);
                }

                if (c.getLapide() == 0) {
                    Aux a = new Aux(c, p);
                    insert(a);
                }
                i++;
            }

            RandomAccessFile generic = fileTmp1;
            boolean tmp = true, tmp2 = false;

            while (arq.getFilePointer() != arq.length()) {
                Aux aux;
                if (tmp) {
                    if (size > 0) {
                        aux = deleteMin();
                        byte[] ba = aux.data.toByteArray();
                        if (aux.peso > ultimo.peso) {
                            p++;
                            tmp2 = !tmp2;
                            if (tmp2) {
                                generic = fileTmp2;
                            } else {
                                generic = fileTmp1;
                            }
                        }
                        generic.writeInt(ba.length);
                        generic.write(ba);

                        ultimo = aux;
                    }
                }

                Conteudo c = new Conteudo();

                tam = arq.readInt();
                byte[] ba = new byte[tam];
                arq.read(ba);
                c = new Conteudo();
                c.fromByteArray(ba);

                if (c.getLapide() == 0) {
                    tmp = true;
                    Aux a;
                    if (c.getId() > ultimo.data.id) {
                        a = new Aux(c, p);
                        insert(a);
                    } else {
                        a = new Aux(c, p + 1);
                        insert(a);
                    }
                } else {
                    tmp = false;
                }
            }

            while (size > 0) {
                Aux aux;

                aux = deleteMin();
                byte[] ba = aux.data.toByteArray();
                if (aux.peso > ultimo.peso) {
                    p++;
                    tmp2 = !tmp2;
                    if (tmp2) {
                        generic = fileTmp2;
                    } else {
                        generic = fileTmp1;
                    }
                }
                generic.writeInt(ba.length);
                generic.write(ba);

                ultimo = aux;

            }

            qReg = readIdBeginning(arq);
            troca = true;
            cont = 0;
            while (quant < qReg) {

                quant = interVariavel(troca, fileTmp1, fileTmp2, fileTmp3, fileTmp4);
                troca = !troca;
                cont++;
            }

            RandomAccessFile arqAux = fileTmp1;

            if (cont % 2 == 0) {
                arqAux = fileTmp1;
            } else {
                arqAux = fileTmp3;
            }

            arqAux.seek(0);
            arq.setLength(0);
            writeIdBeginning(arq, 0);

            Conteudo c = new Conteudo();

            while (arqAux.getFilePointer() != arqAux.length()) {
                arq.seek(arq.length());
                tam = arqAux.readInt();
                byte[] ba = new byte[tam];
                arqAux.read(ba);

                c.fromByteArray(ba);

                arq.writeInt(tam);
                arq.write(ba);

                writeIdBeginning(arq, c.getId());
            }

            arq.close();
            fileTmp1.close();
            fileTmp2.close();
            fileTmp3.close();
            fileTmp4.close();

            File f = new File("tmp1.bin");
            f.delete();
            f = new File("tmp2.bin");
            f.delete();
            f = new File("tmp3.bin");
            f.delete();
            f = new File("tmp4.bin");
            f.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void show() {
        for (int i = 1; i < size + 1; i++)
            if (heap[i] != null)
                System.out.println(heap[i].data.id);
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }
}
