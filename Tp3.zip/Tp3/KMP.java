import java.io.RandomAccessFile;
import java.util.Scanner;

class KMP {

    private static Scanner scan = new Scanner(System.in);

    static int linha, nCmp = 0;

    static boolean KMPSearch(String padrao, String txt, int[] array) {

        boolean found = false;

        int M = padrao.length();
        int N = txt.length();

        int j = 0;

        int i = 0;
        while ((N - i) >= (M - j) && !found) {
            nCmp++;
            if (padrao.charAt(j) == txt.charAt(i)) {
                i++;
                j++;
            }
            nCmp++;
            if (j == M) {
                System.out.println("Encontrado na linha " + linha + ", index " + (i - j));
                j = array[j - 1];

                found = true;
            } else if (i < N && padrao.charAt(j) != txt.charAt(i)) {
                if (j != 0) {
                    j = array[j - 1];
                } else {
                    i += 1;
                }

            }

        }
        return found;
    }

    static void computeLPSArray(String padrao, int M, int[] array) {
        int tam = 0;

        array[0] = 0;
        int i = 1;

        while (i < M) {
            if (padrao.charAt(i) == padrao.charAt(tam)) {
                tam += 1;
                array[i] = tam;
                i++;
            } else {
                if (tam != 0) {
                    tam = array[tam - 1];
                } else {
                    array[i] = 0;
                    i++;
                }
            }
        }

        for (i = 0; i < array.length; i++) {
            System.out.print(array[i] + " ");
        }
        System.out.print("\n");
    }

    public void busca() {

        linha = 1;

        try {

            boolean found = false;
            String padrao;
            int M, tam;
            byte[] ba;
            int[] array;
            Conteudo c = new Conteudo();

            RandomAccessFile arq = new RandomAccessFile("conteudos.bin", "rw");

            arq.seek(4);

            System.out.print("Digite o padrao a ser encontrado: ");
            padrao = scan.nextLine();

            M = padrao.length();

            array = new int[M];

            computeLPSArray(padrao, M, array);

            while (arq.getFilePointer() != arq.length() && !found) {

                tam = arq.readInt();
                ba = new byte[tam];
                arq.read(ba);
                c.fromByteArray(ba);

                String txt = c.toStringNoSpace();

                found = KMPSearch(padrao, txt, array);

                linha++;
            }

            if (found) {
                System.out.println("Numero de comparacoes =  " + nCmp);
            } else {
                System.out.println("Padrao ausente!");
            }

            arq.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

}