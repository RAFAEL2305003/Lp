import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

class Conteudo {

    protected String title, cast, rating;
    public int id, release_year;
    protected Date date_added;
    protected byte lapide;

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getcast() {
        return this.cast;
    }

    public void setcast(String cast) {
        this.cast = cast;
    }

    public String getRating() {
        return this.rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getDate_added() {
        return this.date_added;
    }

    public void setDate_added(Date date_added) {
        this.date_added = date_added;
    }

    public byte getLapide() {
        return this.lapide;
    }

    public void setLapide(byte lapide) {
        this.lapide = lapide;
    }

    public int getReleaseYear() {
        return this.release_year;
    }

    public void setReleaseYear(int release_year) {
        this.release_year = release_year;
    }

    protected DateFormat dateFormat = new SimpleDateFormat("dd/mm/yyyy");

    public Conteudo(int id, String title, String cast, Date date_added, int release_year, String rating) {
        this.id = id;
        this.title = title;
        this.cast = cast;
        this.date_added = date_added;
        this.release_year = release_year;
        this.rating = rating;
        lapide = 0;
    }

    public Conteudo() {
        this(-1, "", "", new Date(), -1, "");
    }

    public String toString() {
        return "\nid: " + id +
                "\nTitle: " + title +
                "\nCast: " + cast +
                "\nRelease year: " + release_year +
                "\nDate added: " + dateFormat.format(date_added) +
                "\nRating: " + rating;
    }

    public String toStringNoSpace() {
        return title + cast + release_year + dateFormat.format(date_added) + rating;
    }

    public byte[] toByteArray() throws IOException {

        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        DataOutputStream dos = new DataOutputStream(baos);

        dos.writeByte(lapide);
        dos.writeInt(id);
        dos.writeUTF(title);
        dos.writeUTF(cast);
        dos.writeUTF(dateFormat.format(date_added));
        dos.writeInt(release_year);
        dos.writeUTF(rating);

        return baos.toByteArray();
    }

    public void fromByteArray(byte ba[]) throws IOException {

        ByteArrayInputStream bais = new ByteArrayInputStream(ba);
        DataInputStream dis = new DataInputStream(bais);
        lapide = dis.readByte();
        id = dis.readInt();
        title = dis.readUTF();
        cast = dis.readUTF();

        try {
            date_added = dateFormat.parse(dis.readUTF());
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        release_year = dis.readInt();
        rating = dis.readUTF();
    }
}