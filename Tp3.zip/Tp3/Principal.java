class Principal extends CRUD {

    public static void main(String[] args) {

        menu();

    }

}