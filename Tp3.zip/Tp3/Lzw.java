import java.util.*;
import java.io.*;

class Lzw {
  // Definindo dados
  private Map<Integer, String> MapDecompress;
  private Map<String, Integer> MapCompress;

  // Construtor padrao
  public Lzw() {
    MapDecompress = new HashMap<>();
    MapCompress = new HashMap<>();

    // Inicializando os dicionarios com toda tabela ascii
    for (int i = 0; i < 256; i++) {
      char c = (char) i;
      MapCompress.put(String.valueOf(c), i);
      MapDecompress.put(i, String.valueOf(c));
    }
  }

  public void compress(String input) {
    String p = "", c = "";
    p += input.charAt(0);

    int size = 256;
    Vector<Integer> v = new Vector<>();
    for (int i = 0; i < input.length(); i++) {
      if (i != input.length() - 1)
        c += input.charAt(i + 1);
      if (MapCompress.containsKey(p + c)) {
        p = p + c;
      } else {
        v.add(MapCompress.get(p));
        MapCompress.put(p + c, size);
        size++;
        p = c;
      }
      c = "";
    }

    v.add(MapCompress.get(p));

    write(v);
  }

  public String decompress() {
    Vector<Integer> v = read();
    String result = "";

    int old = 0, n = 0;

    if (v.get(0) != null) {
      old = v.get(0);
    }

    String s = MapDecompress.get(old);
    String c = "" + s.charAt(0);
    result += s;

    int count = 256;
    for (int i = 0; i < v.size() - 1; i++) {
      if (v.get(i + 1) != null) {
        n = v.get(i + 1);
      }
      if (!MapDecompress.containsKey(n)) {
        s = MapDecompress.get(old);
        s = s + c;
      } else {
        s = MapDecompress.get(n);
      }
      result += s;
      c = "" + s.charAt(0);
      MapDecompress.put(count, MapDecompress.get(old) + c);
      count++;
      old = n;
    }

    return result;
  }

  public void write(Vector<Integer> v) {
    try (RandomAccessFile raf = new RandomAccessFile("NetflixCompressaoLzwX.bin", "rw")) {
      raf.seek(0);
      byte b1, b2, b3;
      for (int i = 0; i < v.size(); i++) {
        if (v.get(i) != null) {
          b3 = (byte) (v.get(i) & 0xFF);

          b2 = (byte) ((v.get(i) >> 8) & 0xFF);

          b1 = (byte) ((v.get(i) >> 16) & 0xFF);

          raf.writeByte(b1);
          raf.writeByte(b2);
          raf.writeByte(b3);

        } else {
          raf.writeByte(0xff);
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
  }

  public Vector<Integer> read() {
    Vector<Integer> v = new Vector<>();
    try (RandomAccessFile raf = new RandomAccessFile("NetflixCompressaoLzwX.bin", "rw")) {
      raf.seek(0);
      int i = 0;
      byte aux, b1, b2, b3;

      while (raf.getFilePointer() < raf.length()) {
        aux = raf.readByte();
        if (aux == -1) {
          v.add(null);
        } else {
          raf.seek(raf.getFilePointer() - 1);
          b1 = raf.readByte();
          b2 = raf.readByte();
          b3 = raf.readByte();
          i = (b3 & 0xFF) | ((b2 & 0xFF) << 8) | ((b1 & 0x0F) << 16);
          v.add(i);
        }
      }
    } catch (IOException e) {
      e.printStackTrace();
    }
    return v;
  }
}
